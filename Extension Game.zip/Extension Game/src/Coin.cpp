#include "Coin.h"
#include "Sprite.h"

Coin::Coin(bool newSolid, int newx, int newy, int newWidth, int newHeight, Sprite* newSprite)
{
    solid = false;
    x = newx;
    y = newy;
    width = newWidth;
    height = newHeight;
    sprite = newSprite;
    frame = new int(0);
    animating = true;
}

Coin::~Coin()
{
    //dtor
}

bool Coin::step()
{
    if (animating == true)
    {
        *frame += 1;
    }
    return true;
}

type Coin::getType()
{
    return COIN;
}
