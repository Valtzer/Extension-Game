#ifndef GLOBALS_H
#define GLOBALS_H

const int TILE_WIDTH = 16;
const int TILE_HEIGHT = 16;

const int ROOM_WIDTH = 200;
const int ROOM_HEIGHT = 15;

const int VIEW_WIDTH = 320;
const int VIEW_HEIGHT = 240;

const int PLAYER_WIDTH = 16;
const int PLAYER_HEIGHT = 26;

const int MASK_WIDTH = 12;
const int MASK_HEIGHT = 26;

typedef enum
{
    RIGHT = 1,
    LEFT = -1
}Direction;

typedef enum
{
    SPRINGPAD = 0,
    SPRINGPADBLUE = 1,
    COIN = 2,
    GEM = 3,
    ANIMATION = 4
}type;


#endif
