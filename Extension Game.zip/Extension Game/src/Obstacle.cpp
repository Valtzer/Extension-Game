#include "Obstacle.h"

Obstacle::Obstacle()
{
    //ctor
}

Obstacle::~Obstacle()
{
    //dtor
}

void Obstacle::draw(SDL_Surface* screen, int viewX, int viewY)
{
    //Do some scribble.
    SDL_Rect currentTile;
    currentTile.x = x-viewX;
    currentTile.y = y-viewY;
    SDL_BlitSurface(sprite->getSheet(), sprite->getFrame(frame), screen, &currentTile);
}

bool Obstacle::getSolid()
{
    return solid;
}

void Obstacle::startAnimating()
{
    animating = true;
    *frame = 1;
}

int Obstacle::getLeft()
{
    return x;
}

int Obstacle::getRight()
{
    return x+width;
}

int Obstacle::getTop()
{
    return y;
}

int Obstacle::getBottom()
{
    return y+height;
}
