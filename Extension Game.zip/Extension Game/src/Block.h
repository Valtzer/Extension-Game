#ifndef BLOCK_H
#define BLOCK_H


class Block
{
    public:
        Block(bool solid, int newx, int newy, int newWidth, int newHeight);
        virtual ~Block();
        bool getSolid();
        int getLeft();
        int getRight();
        int getTop();
        int getBottom();
    protected:
    private:
        bool solid;
        int x;
        int y;
        int width;
        int height;
};

#endif // BLOCK_H
