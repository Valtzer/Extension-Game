#ifndef OBSTACLE_H
#define OBSTACLE_H


#include "sprite.h"
#include "globals.h"

class Obstacle
{
    public:
        Obstacle();
        virtual ~Obstacle();

        bool getSolid();

        int getLeft();
        int getRight();
        int getTop();
        int getBottom();

        virtual bool step() = 0;
        virtual type getType() = 0;
        virtual void startAnimating();

        void draw(SDL_Surface* screen, int viewX, int viewY);

        int getX();
        int getY();
    protected:
        bool solid;
        int x;
        int y;
        int width;
        int height;

        int* frame;
        bool animating;

        Sprite* sprite;
    private:
};

#endif // OBSTACLE_H
