#ifdef __cplusplus
    #include <cstdlib>
#else
    #include <stdlib.h>
#endif
#ifdef __APPLE__
#include <SDL/SDL.h>
#else
#include <SDL.h>
#endif

#include <SDL_image.h>

#include "SpriteManager.h"
#include "Sprite.h"

SpriteManager::SpriteManager()
{
    //ctor
    SDL_Surface* playerSheet = IMG_Load("tiles/playersheet.png");
    SDL_Surface* playerSheetLeft = IMG_Load("tiles/playersheetleft.png");
    loadPlayerStandRight(playerSheet);
    loadPlayerStandLeft(playerSheetLeft);
    loadPlayerRunRight(playerSheet);
    loadPlayerRunLeft(playerSheetLeft);
    loadPlayerJumpRight(playerSheet);
    loadPlayerJumpLeft(playerSheetLeft);
    loadPlayerFallRight(playerSheet);
    loadPlayerFallLeft(playerSheetLeft);
    loadPlayerFallanimRight(playerSheet);
    loadPlayerFallanimLeft(playerSheetLeft);
    loadPlayerDuckRight(playerSheet);
    loadPlayerDuckLeft(playerSheetLeft);

    SDL_Surface* springSheet = IMG_Load("tiles/springpad.png");
    loadSpringPad(springSheet);

    SDL_Surface* coinSheet = IMG_Load("tiles/coin.png");
    loadCoin(coinSheet);

    SDL_Surface* SmallCoinSheet = IMG_Load("tiles/smallcoin.png");
    loadSmallCoin(SmallCoinSheet);

    SDL_Surface* blueGemSheet = IMG_Load("tiles/bluegem.png");
    loadBlueGem(blueGemSheet);

    SDL_Surface* redGemSheet = IMG_Load("tiles/redgem.png");
    loadRedGem(redGemSheet);

    SDL_Surface* sparklySheet = IMG_Load("tiles/sparkly.png");
    loadSparkly(sparklySheet);

}

SpriteManager::~SpriteManager()
{
    //dtor
}

void SpriteManager::loadPlayerStandRight(SDL_Surface* spriteSheet)
{
    playerStandRight = new Sprite(spriteSheet, 16, 26, 1, 0, 0, 1);//Width, height, duration, y position, x position, length of normal frame.
    //playerStand->changeFrameTime(50,4);
}

void SpriteManager::loadPlayerStandLeft(SDL_Surface* spriteSheet)
{
    playerStandLeft = new Sprite(spriteSheet, 16, 26, 1, 0, 0, 1);
}

void SpriteManager::loadPlayerRunRight(SDL_Surface* spriteSheet)
{
    playerRunRight = new Sprite(spriteSheet, 16, 26, 4, 27, 0, 8);
}

void SpriteManager::loadPlayerRunLeft(SDL_Surface* spriteSheet)
{
    playerRunLeft = new Sprite(spriteSheet, 16, 26, 4, 27, 0, 8);
}

void SpriteManager::loadPlayerJumpRight(SDL_Surface* spriteSheet)
{
    playerJumpRight = new Sprite(spriteSheet, 16, 26, 1, 0, 17, 1);
}

void SpriteManager::loadPlayerJumpLeft(SDL_Surface* spriteSheet)
{
    playerJumpLeft = new Sprite(spriteSheet, 16, 26, 1, 0, 17, 1);
}

void SpriteManager::loadPlayerFallRight(SDL_Surface* spriteSheet)
{
    playerFallRight = new Sprite(spriteSheet, 16, 26, 1, 0, 34, 1);
}

void SpriteManager::loadPlayerFallLeft(SDL_Surface* spriteSheet)
{
    playerFallLeft = new Sprite(spriteSheet, 16, 26, 1, 0, 34, 1);
}

void SpriteManager::loadPlayerFallanimRight(SDL_Surface* spriteSheet)
{
    playerFallanimRight = new Sprite(spriteSheet, 16, 26, 4, 54, 0, 3);
}

void SpriteManager::loadPlayerFallanimLeft(SDL_Surface* spriteSheet)
{
    playerFallanimLeft = new Sprite(spriteSheet, 16, 26, 4, 54, 0, 3);
}

void SpriteManager::loadPlayerDuckRight(SDL_Surface* spriteSheet)
{
    playerDuckRight = new Sprite(spriteSheet, 16, 26, 1, 0, 51, 1);
}

void SpriteManager::loadPlayerDuckLeft(SDL_Surface* spriteSheet)
{
    playerDuckLeft = new Sprite(spriteSheet, 16, 26, 1, 0, 51, 1);
}


void SpriteManager::loadSpringPad(SDL_Surface* spriteSheet)
{
    springPad = new Sprite(spriteSheet, 16, 16, 4, 0, 0, 3);
}

void SpriteManager::loadCoin(SDL_Surface* spriteSheet)
{
    coin = new Sprite(spriteSheet, 16, 16, 6, 0, 0, 5);
}

void SpriteManager::loadSmallCoin(SDL_Surface* spriteSheet)
{
    smallCoin = new Sprite(spriteSheet, 8, 8, 6, 0, 0, 5);
}

void SpriteManager::loadBlueGem(SDL_Surface* spriteSheet)
{
    blueGem = new Sprite(spriteSheet, 12, 12, 6, 0, 0, 5);
}

void SpriteManager::loadRedGem(SDL_Surface* spriteSheet)
{
    redGem = new Sprite(spriteSheet, 16, 16, 6, 0, 0, 5);
}

void SpriteManager::loadSparkly(SDL_Surface* spriteSheet)
{
    sparkly = new Sprite(spriteSheet, 14, 14, 7, 0, 0, 3);
}
