#include "Springpad.h"
#include "Sprite.h"

Springpad::Springpad(bool newSolid, int newx, int newy, int newWidth, int newHeight, Sprite* newSprite)
{
    solid = true;
    x = newx;
    y = newy;
    width = newWidth;
    height = newHeight;
    sprite = newSprite;
    frame = new int(0);
    animating = false;
    //ctor
}

Springpad::~Springpad()
{
    //dtor
}

bool Springpad::step()
{
    if (*frame == 0)
    {
        animating = false;
    }
    if (animating == true)
    {
        *frame += 1;
    }
    return true;
}

type Springpad::getType()
{
    return SPRINGPAD;
}
