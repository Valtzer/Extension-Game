#ifdef __cplusplus
    #include <cstdlib>
#else
    #include <stdlib.h>
#endif
#ifdef __APPLE__
#include <SDL/SDL.h>
#else
#include <SDL.h>
#endif

#include "Animation.h"

Animation::Animation()
{
    //ctor
}

Animation::~Animation()
{
    //dtor
}

void Animation::addFrame(int x, int y, int width, int height, int frameEndtime)
{
    SDL_Rect* input;
    input = new SDL_Rect();
    input->x = x;
    input->y = y;
    input->w = width;
    input->h = height;
    images.push_back(input);
    frameTimes.push_back(frameEndtime);
}

SDL_Rect* Animation::getFrame(int* frame)
{
    //Assume 25 steps to a frame. Why? Cause it's the default I'm testing with.
    //Ahhhh, check the value passed in against the values in frametimes. Find the highest index that the passed value si higher than and return that.
    //If it's the last, set the number back to 0 for the calling object.
    int i;
    for(i = 0; i < frameTimes.size(); i += 1)
    {
        if (*frame > frameTimes[i])
        {
            //We don't care.
        }
        else
        {
            //We do care.

            return images[i];

        }
    }
    *frame = 0;//Reset the frames to the start of the animation.
    return images[images.size()-1];
}

void Animation::changeFrameTime(int time, int frame)
{
    for(int i = frame; i < frameTimes.size(); i += 1)
    {
        frameTimes[i] += time;
    }
}
