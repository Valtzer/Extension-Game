#ifdef __cplusplus
    #include <cstdlib>
#else
    #include <stdlib.h>
#endif
#ifdef __APPLE__
#include <SDL/SDL.h>
#else
#include <SDL.h>
#endif

#include <vector>

#include "globals.h"
#include "Coin.h"
#include "Gem.h"
#include "Springpad.h"
#include "AnimationObject.h"

#include "Obstacle.h"
#include "Room.h"

using namespace std;

Room::Room(SDL_Surface* newTiles, SDL_Surface* newScreen, SDL_Surface* newBackground, SDL_Surface* newBackgroundfloor, SDL_Surface* newParallaxback, SDL_Surface* newParallaxbackupper, SpriteManager* spriteControl)
{
    tileEqualsCell = {17, 34, TILE_WIDTH, TILE_HEIGHT};
    tileLeftTriangleCell = {0, 34, TILE_WIDTH, TILE_HEIGHT};
    tileRightTriangleCell = {34, 34, TILE_WIDTH, TILE_HEIGHT};
    tileICell = {17, 0, TILE_WIDTH, TILE_HEIGHT};
    tileSpaceCell = {0, 17, TILE_WIDTH, TILE_HEIGHT};
    tileSignCell = {0, 0, TILE_WIDTH, TILE_HEIGHT};
    tileGrassCell = {17, 17, TILE_WIDTH, TILE_HEIGHT};
    tileHalfCell = {34, 0, TILE_WIDTH, TILE_HEIGHT};
    tileHalfMidCell = {51, 0, TILE_WIDTH, TILE_HEIGHT};
    tileHalfHighCell = {68, 0, TILE_WIDTH, TILE_HEIGHT};
    tileCannonStandCell = {51, 34, TILE_WIDTH, TILE_HEIGHT};
    tileCannonCell = {51, 17, TILE_WIDTH, TILE_HEIGHT};
    tileGatlingCell = {68, 17, TILE_WIDTH, TILE_HEIGHT};

    tileSet = newTiles;
    xTiles = ROOM_WIDTH;
    yTiles = ROOM_HEIGHT;
    screen = newScreen;
    background = newBackground;
    backgroundFloor = newBackgroundfloor;
    parallaxBack = newParallaxback;
    parallaxBackupper = newParallaxbackupper;

    viewX = 0;
    viewY = 0;

    xBorder = 160;
    yBorder = 120;

    theHud = new Hud(spriteControl);

    sparkly = spriteControl->sparkly;

    grid = {{'=','=','=','=','=','=','>',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
            {'I',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','.',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','r','S',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','.',' ',' ',' ',' ',' ',' ',' ','.',' ','S',' ',' ',' ','b','r','r','r','b',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
            {'I',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ','.',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','<','=','=','=','>',' ',' ',' ',' ','b','b',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','.','b','r','b',' ',' ',' ',' ',' ',' ','<','=','=','>',' ',' ',' ',' ',' ',' ','<','=','=','=','=','>',' ',' ',' ',' ',' ','^','^','^','^','&','_','_','_','_','_','_','_',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','b','r','r','b',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','<','='},
            {'I','=','>',' ',' ','I',' ',' ',' ',' ',' ',' ','<','=','=','=','>',' ',' ',' ','r','.','r',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','<','=','=','>',' ',' ',' ',' ',' ',' ','b','b','_','&','=','=','=','=','=','=','>',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I','&','_','.',' ',' ',' ',' ',' ',' ','<','=','=','=','=','>',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ','<','=','=','=','>',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
            {'I',' ',' ',' ',' ','I',' ','.',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','<','=','=','=','>',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','b','b','_','&','^',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ','^','&','_','_',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I','.',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ','<','=','=','=','>',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','<','=','=','>',' ',' ','<','>',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
            {'I',' ',' ',' ','<','=','=','=','>','_',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','S','_','&','^',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I','r','b','.',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','<','=','=','=','>',' ',' ',' ',' ',' ',' ',' ',' ',' ','.',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','<','=','>',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ','<','=','=','=','>',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','<','='},
            {'I',' ',' ',' ',' ',' ',' ',' ',' ','^',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ','_',' ',' ','_',' ',' ',' ',' ',' ',' ',' ',' ',' ','<','=','>',' ',' ',' ',' ',' ',' ','b','b','_','&','^',' ',' ',' ',' ',' ',' ',' ','I','=','=','>',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','.',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ','.',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','_','^','^','^',' ',' ',' ','_','_',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ','<','=','>',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
            {'I','b',' ','.',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','.',' ',' ',' ',' ','I',' ',' ',' ','b','b','_','&','^',' ',' ','^','&','_','r','.',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ','_','&','&','^',' ',' ',' ',' ',' ',' ',' ',' ',' ','I','b',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','<','=','=','=','>',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ','<','=','=','=','>',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','.',' ','_','^',' ',' ',' ',' ',' ',' ',' ',' ','^','&','_',' ',' ',' ',' ','.',' ',' ',' ','.','I',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
            {'I','=','=','>',' ',' ',' ',' ',' ',' ',' ','.','_','&','<','=','>',' ',' ',' ','I',' ',' ','<','=','=','=','>',' ',' ',' ',' ','<','=','=','=','>',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I','r','b',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ','S',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ','%',' ',' ',' ',' ','I',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','_','<','=','=','>',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','^','&','=','=','=','=','=','=','=','=','=','>',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ','<','=','>',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','<','='},
            {'I',' ',' ',' ',' ',' ',' ',' ',' ',' ','_','&','^','I',' ',' ',' ',' ',' ',' ','I',' ',' ',' ','I',' ',' ',' ',' ','S',' ',' ',' ',' ',' ','I',' ',' ',' ',' ','.',' ','I',' ','.',' ',' ',' ',' ','I',' ',' ',' ',' ',' ','b','r','b','S',' ',' ',' ','I','b','.',' ',' ','%',' ','_','^',' ',' ','I',' ',' ',' ','<','=','=','=','>',' ',' ',' ',' ','I',' ',' ',' ',' ','.','b','I','.',' ',' ',' ',' ','<','=','=','>',' ',' ',' ','I',' ','.',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','_','&','^',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ','<','=','=','>',' ','&',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
            {'I',' ',' ',' ',' ',' ',' ','S','_','&','^',' ',' ','I',' ',' ',' ','S',' ','.','I','b',' ',' ','I','b','b','b',' ','&','&',' ','b','b','b','I',' ',' ',' ','<','=','=','=','=','=','>',' ',' ','b','I',' ',' ',' ','_','&','=','=','=','=','=','=','=','=','=','=','=','=','=','>',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ','<','=','=','=','>','_',' ',' ',' ','I',' ',' ',' ',' ','<','=','=','=','>',' ',' ','I',' ',' ',' ',' ',' ',' ',' ','.','_','&','^',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','.',' ',' ',' ',' ',' ','S',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ','&',' ','&',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','_',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
            {'I',' ',' ',' ',' ','<','=','=','=','>',' ',' ',' ','I',' ',' ','<','=','=','=','=','>',' ',' ','I','b','r','b',' ',' ',' ',' ','b','r','b','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','<','I',' ',' ','^','^',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I','b','b','b',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ','<','=','=','=','>',' ',' ',' ',' ',' ',' ',' ','_','_','_','_',' ',' ',' ',' ','^','^','&','&','&','&','&','&','&','&','&','&','^','^','&','&','&','&','_',' ',' ',' ',' ',' ','^','^','^',' ',' ',' ','<','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','&',' ',' ',' ',' ',' ','%',' ',' ',' ',' ',' ',' ','<','='},
            {'I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I','b','b','b',' ',' ',' ',' ','b','b','b','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','G','I','b','r','b',' ',' ',' ',' ',' ',' ',' ',' ','C','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','C','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','_','&','^',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','^','&','&','&','^',' ',' ',' ',' ',' ',' ',' ',' ','^','&','_',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','G',' ',' ','&',' ',' ',' ',' ','&','&','&',' ',' ',' ',' ',' ',' ',' '},
            {'I',' ','.',' ',' ',' ',' ',' ','.',' ','b','r','b','I','.','b','b','b','.',' ',' ',' ','.',' ','I',' ','.',' ','%','.',' ','%',' ','.',' ','I','&','_',' ','.',' ','b','r','r','b',' ',' ',' ',' ','I','b','b','b','b','.',' ','b','r','r','b','.',' ','b','b','b',' ','.',' ','b','b',' ',' ','P','I','b','b','b',' ',' ','c',' ',' ',' ','.',' ','P','I',' ','.',' ',' ',' ',' ',' ','.','b',' ',' ',' ',' ','I',' ',' ','.',' ',' ',' ',' ',' ',' ',' ','P','I',' ','.',' ','b','r','b',' ','.',' ',' ',' ',' ',' ','_','&','^',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','^','&','^',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','^','&','_',' ',' ',' ',' ',' ',' ',' ',' ','I',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','P',' ',' ','&',' ',' ',' ',' ','&','&','&',' ',' ',' ',' ',' ',' ',' '},
            {'=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','>',' ',' ',' ','<','=','=','=','=','=','=','=','=','=','>','_',' ','<','=','>',' ',' ','<','=','=','=','=','=','>',' ',' ','<','=','=','=','=','=','=','>','^','^','^','<','=','=','=','=','=','=','>',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','&',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','^','&','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','=','>',' ',' ',' ','<','='}};

    int x;
    int y;
    for (y = 0; y < yTiles; y += 1)
    {
        for (x = 0; x < xTiles; x += 1)
        {
            if (grid[y][x] == ' ' || grid[y][x] == '.' || grid[y][x] == 'S')
            {
                collisionGrid[y][x] = new Block(false, x*16, y*16, 16, 16);
            }
            else
            if (grid[y][x] == '_')
            {
                collisionGrid[y][x] = new Block(true, x*16, (y*16)+8, 16, 8);
            }
            else
            if (grid[y][x] == '^')
            {
                collisionGrid[y][x] = new Block(true, x*16, (y*16), 16, 8);
            }
            else
            if (grid[y][x] == '%')
            {
                collisionGrid[y][x] = new Block(false, x*16, (y*16), 16, 8);
                objects.push_back(new Springpad(true, x*16, y*16, 16, 16, spriteControl->springPad));
            }
            else
            if (grid[y][x] == 'c')
            {
                collisionGrid[y][x] = new Block(false, x*16, (y*16), 16, 8);
                objects.push_back(new Coin(false, x*16, y*16, 16, 16, spriteControl->coin));
            }
            else
            if (grid[y][x] == 'b')
            {
                collisionGrid[y][x] = new Block(false, x*16, (y*16), 16, 8);
                objects.push_back(new Gem(false, (x*16)+2, (y*16)+2, 12, 12, spriteControl->blueGem));
            }
            else
            if (grid[y][x] == 'r')
            {
                collisionGrid[y][x] = new Block(false, x*16, (y*16), 16, 8);
                objects.push_back(new Gem(false, (x*16), (y*16)-1, 16, 16, spriteControl->redGem));
            }
            else
            {
                collisionGrid[y][x] = new Block(true, x*16, y*16, 16, 16);
            }
        }
    }
}

Room::~Room()
{
    //dtor
}

void Room::step()
{
    int i;
    for (i = 0; i < objects.size(); i += 1)
    {
        if (objects[i]->step() == false)
        {
            objects.erase(objects.begin()+i);
        }
    }
    theHud->step();
}

void Room::draw()
{
    int x;
    int y;
    int i = 0;
    SDL_Rect currentTile;

    currentTile.x = 0;
    currentTile.y = 0;
    SDL_BlitSurface(background, 0, screen, &currentTile);

    currentTile.x = -viewX/10;
    currentTile.y = 0;
    SDL_BlitSurface(parallaxBack, 0, screen, &currentTile);

    currentTile.x = VIEW_WIDTH-viewX/10;
    currentTile.y = 0;
    SDL_BlitSurface(parallaxBack, 0, screen, &currentTile);

    currentTile.x = VIEW_WIDTH*2-viewX/10;
    currentTile.y = 0;
    SDL_BlitSurface(parallaxBack, 0, screen, &currentTile);

    currentTile.x = -viewX/5;
    currentTile.y = 0;
    SDL_BlitSurface(parallaxBackupper, 0, screen, &currentTile);

    currentTile.x = VIEW_WIDTH-viewX/5;
    currentTile.y = 0;
    SDL_BlitSurface(parallaxBackupper, 0, screen, &currentTile);

    currentTile.x = VIEW_WIDTH*2-viewX/5;
    currentTile.y = 0;
    SDL_BlitSurface(parallaxBackupper, 0, screen, &currentTile);

    currentTile.x = VIEW_WIDTH*3-viewX/5;
    currentTile.y = 0;
    SDL_BlitSurface(parallaxBackupper, 0, screen, &currentTile);

    currentTile.x = 0;
    currentTile.y = 0;
    SDL_BlitSurface(backgroundFloor, 0, screen, &currentTile);

    for (y = 0; y < yTiles; y += 1)
    {
        for (x = 0; x < xTiles; x += 1)
        {
            if (x*16> viewX-32 && x*16 < viewX+VIEW_WIDTH+32 && y*16 > viewY-32 && viewY+VIEW_HEIGHT+32)
            {
                if (grid[y][x] == '=')
                {
                    currentTile.x = (x*16)-viewX;
                    currentTile.y = (y*16)-viewY;
                    SDL_BlitSurface(tileSet, &tileEqualsCell, screen, &currentTile);
                }
                if (grid[y][x] == '<')
                {
                    currentTile.x = (x*16)-viewX;
                    currentTile.y = (y*16)-viewY;
                    SDL_BlitSurface(tileSet, &tileLeftTriangleCell, screen, &currentTile);
                }
                if (grid[y][x] == '>')
                {
                    currentTile.x = (x*16)-viewX;
                    currentTile.y = (y*16)-viewY;
                    SDL_BlitSurface(tileSet, &tileRightTriangleCell, screen, &currentTile);
                }
                if (grid[y][x] == 'I')
                {
                    currentTile.x = (x*16)-viewX;
                    currentTile.y = (y*16)-viewY;
                    SDL_BlitSurface(tileSet, &tileICell, screen, &currentTile);
                }
                if (grid[y][x] == 'S')
                {
                    currentTile.x = (x*16)-viewX;
                    currentTile.y = (y*16)-viewY;
                    SDL_BlitSurface(tileSet, &tileSignCell, screen, &currentTile);
                }
                if (grid[y][x] == 'P')
                {
                    currentTile.x = (x*16)-viewX;
                    currentTile.y = (y*16)-viewY;
                    SDL_BlitSurface(tileSet, &tileCannonStandCell, screen, &currentTile);
                }
                if (grid[y][x] == 'G')
                {
                    currentTile.x = (x*16)-viewX;
                    currentTile.y = (y*16)-viewY;
                    SDL_BlitSurface(tileSet, &tileGatlingCell, screen, &currentTile);
                }
                if (grid[y][x] == 'C')
                {
                    currentTile.x = (x*16)-viewX;
                    currentTile.y = (y*16)-viewY;
                    SDL_BlitSurface(tileSet, &tileCannonCell, screen, &currentTile);
                }
                if (grid[y][x] == '.')
                {
                    currentTile.x = (x*16)-viewX;
                    currentTile.y = (y*16)-viewY;
                    SDL_BlitSurface(tileSet, &tileGrassCell, screen, &currentTile);
                }
                if (grid[y][x] == '_')
                {
                    currentTile.x = (x*16)-viewX;
                    currentTile.y = (y*16)-viewY;
                    SDL_BlitSurface(tileSet, &tileHalfCell, screen, &currentTile);
                }
                if (grid[y][x] == '&')
                {
                    currentTile.x = (x*16)-viewX;
                    currentTile.y = (y*16)-viewY;
                    SDL_BlitSurface(tileSet, &tileHalfMidCell, screen, &currentTile);
                }
                if (grid[y][x] == '^')
                {
                    currentTile.x = (x*16)-viewX;
                    currentTile.y = (y*16)-viewY;
                    SDL_BlitSurface(tileSet, &tileHalfHighCell, screen, &currentTile);
                }
            }
        }
    }
    for (i = 0; i < objects.size(); i += 1)
    {
        objects[i]->draw(screen,viewX,viewY);
    }
    theHud->draw(screen,viewX,viewY);
}


bool Room::placeFree(int x, int y, int width, int height, int startx, int starty, int xOrigin, int yOrigin)
{
    int xOffset = 0;
    int yOffset = 0;
    int i;
    int j;

    int xLeft = x-width/2;
    int xRight = x+width/2;
    int yTop = y-height/2;
    int yBottom = y+height/2;

    int boxLeft;
    int boxRight;
    int boxTop;
    int boxBottom;

    xOffset = (width/2)-(xOrigin);
    yOffset = (height/2)-(yOrigin);

    for (i = 0; i < yTiles; i += 1)
    {
        for (j = 0; j < xTiles; j += 1)
        {
            if (collisionGrid[i][j]->getSolid() == true)
            {
                //collisionGrid[y][x]//Compare this thing's boundaries to the parameter boundaries.
                boxLeft = collisionGrid[i][j]->getLeft();
                boxRight  = collisionGrid[i][j]->getRight();
                boxTop = collisionGrid[i][j]->getTop();
                boxBottom  = collisionGrid[i][j]->getBottom();


                if(xLeft < boxRight && xRight >= boxRight)
                {
                    if ((yTop < boxBottom && yBottom > boxBottom) || (yBottom > boxTop && yTop < boxTop))
                    {
                        return false;
                    }
                }
                if(xRight > boxLeft && xLeft <= boxLeft)
                {
                    if ((yTop < boxBottom && yBottom > boxBottom) || (yBottom > boxTop && yTop < boxTop))
                    {
                        return false;
                    }
                }
                if(xRight > boxLeft && xLeft >= boxLeft && xLeft < boxRight && xRight <= boxRight)
                {
                    if ((yTop < boxBottom && yBottom > boxBottom) || (yBottom > boxTop && yTop < boxTop))
                    {
                        return false;
                    }
                }
            }
        }
    }
    for (i = 0; i < objects.size(); i += 1)
    {
        if (objects[i]->getSolid() == true)
        {
            //collisionGrid[y][x]//Compare this thing's boundaries to the parameter boundaries.
            boxLeft = objects[i]->getLeft();
            boxRight  = objects[i]->getRight();
            boxTop = objects[i]->getTop();
            boxBottom  = objects[i]->getBottom();
            if(xLeft < boxRight && xRight >= boxRight)
            {
                if ((yTop < boxBottom && yBottom > boxBottom) || (yBottom > boxTop && yTop < boxTop))
                {
                    return false;
                }
            }
            if(xRight > boxLeft && xLeft <= boxLeft)
            {
                if ((yTop < boxBottom && yBottom > boxBottom) || (yBottom > boxTop && yTop < boxTop))
                {
                    return false;
                }
            }
            if(xRight > boxLeft && xLeft >= boxLeft && xLeft < boxRight && xRight <= boxRight)
            {
                if ((yTop < boxBottom && yBottom > boxBottom) || (yBottom > boxTop && yTop < boxTop))
                {
                    return false;
                }
            }
        }
    }
    return true;
}

bool Room::isFloor(int x, int y, int width, int height, int startx, int starty, int xOrigin, int yOrigin)
{
    int xOffset = 0;
    int yOffset = 0;
    int i;
    int j;

    int xLeft = x-width/2;
    int xRight = x+width/2;
    int yTop = y-height/2;
    int yBottom = y+height/2;

    int boxLeft;
    int boxRight;
    int boxTop;
    int boxBottom;

    xOffset = (width/2)-(xOrigin);
    yOffset = (height/2)-(yOrigin);

    for (i = 0; i < yTiles; i += 1)
    {
        for (j = 0; j < xTiles; j += 1)
        {
            if (collisionGrid[i][j]->getSolid() == true)
            {
                //collisionGrid[y][x]//Compare this thing's boundaries to the parameter boundaries.
                boxLeft = collisionGrid[i][j]->getLeft();
                boxRight  = collisionGrid[i][j]->getRight();
                boxTop = collisionGrid[i][j]->getTop();
                boxBottom  = collisionGrid[i][j]->getBottom();


                if(xLeft < boxRight && xRight >= boxRight)
                {
                    if ((yTop < boxBottom && yBottom > boxBottom) || (yBottom > boxTop && yTop < boxTop))
                    {
                        return true;
                    }
                }
                if(xRight > boxLeft && xLeft <= boxLeft)
                {
                    if ((yTop < boxBottom && yBottom > boxBottom) || (yBottom > boxTop && yTop < boxTop))
                    {
                        return true;
                    }
                }
                if(xRight > boxLeft && xLeft >= boxLeft && xLeft < boxRight && xRight <= boxRight)
                {
                    if ((yTop < boxBottom && yBottom > boxBottom) || (yBottom > boxTop && yTop < boxTop))
                    {
                        return true;
                    }
                }
            }
        }
    }
    for (i = 0; i < objects.size(); i += 1)
    {
        if (objects[i]->getSolid() == true)
        {
            //collisionGrid[y][x]//Compare this thing's boundaries to the parameter boundaries.
            boxLeft = objects[i]->getLeft();
            boxRight  = objects[i]->getRight();
            boxTop = objects[i]->getTop();
            boxBottom  = objects[i]->getBottom();
            if(xLeft < boxRight && xRight >= boxRight)
            {
                if ((yTop < boxBottom && yBottom > boxBottom) || (yBottom > boxTop && yTop < boxTop))
                {
                    return false;
                }
            }
            if(xRight > boxLeft && xLeft <= boxLeft)
            {
                if ((yTop < boxBottom && yBottom > boxBottom) || (yBottom > boxTop && yTop < boxTop))
                {
                    return false;
                }
            }
            if(xRight > boxLeft && xLeft >= boxLeft && xLeft < boxRight && xRight <= boxRight)
            {
                if ((yTop < boxBottom && yBottom > boxBottom) || (yBottom > boxTop && yTop < boxTop))
                {
                    return false;
                }
            }
        }
    }
    return false;
}

Obstacle* Room::objectAtPlace(int x, int y, int width, int height, int startx, int starty, int xOrigin, int yOrigin)
{
    int xOffset = 0;
    int yOffset = 0;
    int i;
    int j;

    int xLeft = x-width/2;
    int xRight = x+width/2;
    int yTop = y-height/2;
    int yBottom = y+height/2;

    int boxLeft;
    int boxRight;
    int boxTop;
    int boxBottom;

    xOffset = (width/2)-(xOrigin);
    yOffset = (height/2)-(yOrigin);
    for (i = 0; i < objects.size(); i += 1)
    {
            boxLeft = objects[i]->getLeft();
            boxRight  = objects[i]->getRight();
            boxTop = objects[i]->getTop();
            boxBottom  = objects[i]->getBottom();
            if(xLeft < boxRight && xRight >= boxRight)
            {
                if ((yTop < boxBottom && yBottom > boxBottom) || (yBottom > boxTop && yTop < boxTop))
                {
                    return objects[i];
                }
            }
            if(xRight > boxLeft && xLeft <= boxLeft)
            {
                if ((yTop < boxBottom && yBottom > boxBottom) || (yBottom > boxTop && yTop < boxTop))
                {
                    return objects[i];
                }
            }
            if(xRight > boxLeft && xLeft >= boxLeft && xLeft < boxRight && xRight <= boxRight)
            {
                if ((yTop < boxBottom && yBottom > boxBottom) || (yBottom > boxTop && yTop < boxTop))
                {
                    return objects[i];
                }
            }
    }
    return 0;
}

int Room::getXView()
{
    return viewX;
}

int Room::getYView()
{
    return viewY;
}

void Room::setView(int x, int y)
{
    //So if we get x = 160 we want viewX to be 0.
    x -= xBorder;
    if (x < 0)
    {
        x = 0;
    }
    if (x > (ROOM_WIDTH*TILE_WIDTH)-VIEW_WIDTH)
    {
        x = (ROOM_WIDTH*TILE_WIDTH)-VIEW_WIDTH;
    }
    viewX = x;

    y -= yBorder;
    if (y < 0)
    {
        y = 0;
    }
    if (y > (ROOM_HEIGHT*TILE_HEIGHT)-VIEW_HEIGHT)
    {
        y = (ROOM_HEIGHT*TILE_HEIGHT)-VIEW_HEIGHT;
    }
    viewY = y;
}

void Room::collectObject(Obstacle* theObject)
{
    int i = 0;
    int x = 0;
    int y = 0;
    int width = 0;
    int height = 0;
    for (i = 0; i < objects.size(); i += 1)
    {
        if (objects[i] == theObject)
        {
            x = theObject->getLeft();
            y = theObject->getTop();
            width = theObject->getRight()-theObject->getLeft();
            height = theObject->getBottom()-theObject->getTop();
            objects.erase(objects.begin()+i);
            objects.push_back(new AnimationObject(false, x+width/2-7, y+height/2-7, 14, 14, sparkly));
            break;
        }
    }
}
