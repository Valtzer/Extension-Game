#ifndef PLAYER_H
#define PLAYER_H

#ifdef __cplusplus
    #include <cstdlib>
#else
    #include <stdlib.h>
#endif
#ifdef __APPLE__
#include <SDL/SDL.h>
#else
#include <SDL.h>
#endif

#include "SpriteManager.h"
#include "Sprite.h"

#include "globals.h"
#include "Room.h"
#include "Block.h"

class Player
{
    public:
        Player(/*SDL_Surface* newSheet, SDL_Surface* newSheetleft, */SDL_Surface* newScreen, int startX, int startY, SpriteManager* spriteControl);
        virtual ~Player();
        void draw();
        void setLevel(Room* newLevel);
        void step();
    protected:
    private:
        //SDL_Surface* spritesheet;
        //SDL_Surface* spritesheetleft;
        SDL_Surface* screen;
        //SDL_Rect standRight;
        int x;
        int y;
        Direction facing;
        int xOrigin;
        int yOrigin;
        float gravity;
        float vspeed;
        int jumpSpeed;
        Room* currentLevel;
        Uint8 *keystates;

        Sprite* standRight;
        Sprite* standLeft;
        Sprite* runRight;
        Sprite* runLeft;
        Sprite* jumpRight;
        Sprite* jumpLeft;
        Sprite* fallRight;
        Sprite* fallLeft;
        Sprite* fallanimRight;
        Sprite* fallanimLeft;
        Sprite* duckRight;
        Sprite* duckLeft;

        Sprite* currentSprite;

        int* frame;
        bool animationEnded;
};

#endif // PLAYER_H
