#include "Gem.h"
#include "Sprite.h"

Gem::Gem(bool newSolid, int newx, int newy, int newWidth, int newHeight, Sprite* newSprite)
{
    solid = false;
    x = newx;
    y = newy;
    width = newWidth;
    height = newHeight;
    sprite = newSprite;
    frame = new int(0);
    animating = true;
    //ctor
}

Gem::~Gem()
{
    //dtor
}

bool Gem::step()
{

    if (solid == true)
    {
        *frame -= 1;
    }
    if (animating == true)
    {
        *frame += 1;
    }
    return true;
}

type Gem::getType()
{
    return GEM;
}

void Gem::collect()
{
    //Remove self from the room, and add some lovely lovely points!
}
