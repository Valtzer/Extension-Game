#ifndef SPRITEMANAGER_H
#define SPRITEMANAGER_H

#ifdef __cplusplus
    #include <cstdlib>
#else
    #include <stdlib.h>
#endif
#ifdef __APPLE__
#include <SDL/SDL.h>
#else
#include <SDL.h>
#endif

#include "Sprite.h"


class SpriteManager
{
    public:
        SpriteManager();
        virtual ~SpriteManager();

        Sprite* playerStandRight;
        Sprite* playerStandLeft;
        Sprite* playerRunRight;
        Sprite* playerRunLeft;
        Sprite* playerJumpRight;
        Sprite* playerJumpLeft;
        Sprite* playerFallRight;
        Sprite* playerFallLeft;
        Sprite* playerFallanimRight;
        Sprite* playerFallanimLeft;
        Sprite* playerDuckRight;
        Sprite* playerDuckLeft;

        Sprite* springPad;
        Sprite* coin;
        Sprite* smallCoin;
        Sprite* blueGem;
        Sprite* redGem;
        Sprite* sparkly;
    protected:
    private:
        void loadPlayerStandRight(SDL_Surface* sheet);
        void loadPlayerStandLeft(SDL_Surface* sheet);
        void loadPlayerRunRight(SDL_Surface* sheet);
        void loadPlayerRunLeft(SDL_Surface* sheet);
        void loadPlayerJumpRight(SDL_Surface* sheet);
        void loadPlayerJumpLeft(SDL_Surface* sheet);
        void loadPlayerFallRight(SDL_Surface* sheet);
        void loadPlayerFallLeft(SDL_Surface* sheet);
        void loadPlayerFallanimRight(SDL_Surface* sheet);
        void loadPlayerFallanimLeft(SDL_Surface* sheet);
        void loadPlayerDuckRight(SDL_Surface* sheet);
        void loadPlayerDuckLeft(SDL_Surface* sheet);

        void loadSpringPad(SDL_Surface* sheet);
        void loadCoin(SDL_Surface* sheet);
        void loadSmallCoin(SDL_Surface* sheet);
        void loadBlueGem(SDL_Surface* sheet);
        void loadRedGem(SDL_Surface* sheet);
        void loadSparkly(SDL_Surface* sheet);
};

#endif // SPRITEMANAGER_H
