#ifndef ROOM_H
#define ROOM_H

#ifdef __cplusplus
    #include <cstdlib>
#else
    #include <stdlib.h>
#endif
#ifdef __APPLE__
#include <SDL/SDL.h>
#else
#include <SDL.h>
#endif

#include "SpriteManager.h"

#include "globals.h"
#include "Obstacle.h"
#include "Block.h"
#include "Hud.h"

#include <vector>

using namespace std;

class Room
{
    public:
        Room(SDL_Surface* newTiles, SDL_Surface* newScreen, SDL_Surface* newBackground, SDL_Surface* newBackgroundfloor, SDL_Surface* newParallaxback, SDL_Surface* newParallaxbackupper, SpriteManager* spriteControl);
        virtual ~Room();
        void draw();
        bool placeFree(int x, int y, int width, int height, int startx, int starty, int xOrigin, int yOrigin);
        bool isFloor(int x, int y, int width, int height, int startx, int starty, int xOrigin, int yOrigin);
        Obstacle* objectAtPlace(int x, int y, int width, int height, int startx, int starty, int xOrigin, int yOrigin);

        int getXView();
        int getYView();
        void setView(int x, int y);

        void step();

        void collectObject(Obstacle* theObject);
    protected:
    private:
        Hud* theHud;

        SDL_Surface* tileSet;
        SDL_Surface* screen;
        SDL_Surface* background;
        SDL_Surface* backgroundFloor;
        SDL_Surface* parallaxBack;
        SDL_Surface* parallaxBackupper;

        int xTiles;
        int yTiles;

        char grid[ROOM_HEIGHT][ROOM_WIDTH];
        Block* collisionGrid[ROOM_HEIGHT][ROOM_WIDTH];
        SDL_Rect tileEqualsCell;
        SDL_Rect tileICell;
        SDL_Rect tileSpaceCell;
        SDL_Rect tileLeftTriangleCell;
        SDL_Rect tileRightTriangleCell;
        SDL_Rect tileSignCell;
        SDL_Rect tileGrassCell;
        SDL_Rect tileHalfCell;
        SDL_Rect tileHalfMidCell;
        SDL_Rect tileHalfHighCell;
        SDL_Rect tileCannonStandCell;
        SDL_Rect tileCannonCell;
        SDL_Rect tileGatlingCell;

        int viewX;
        int viewY;

        int xBorder;
        int yBorder;

        vector<Obstacle*> objects;

        Sprite* sparkly;

};

#endif // ROOM_H
