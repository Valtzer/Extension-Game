#include "Block.h"

Block::Block(bool newSolid, int newx, int newy, int newWidth, int newHeight)
{
    solid = newSolid;
    x = newx;
    y = newy;
    width = newWidth;
    height = newHeight;
    //ctor
}

Block::~Block()
{
    //dtor
}

bool Block::getSolid()
{
    return solid;
}

int Block::getLeft()
{
    return x;
}

int Block::getRight()
{
    return x+width;
}

int Block::getTop()
{
    return y;
}

int Block::getBottom()
{
    return y+height;
}
