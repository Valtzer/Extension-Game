#include "AnimationObject.h"

AnimationObject::AnimationObject(bool newSolid, int newx, int newy, int newWidth, int newHeight, Sprite* newSprite)
{
    solid = false;
    x = newx;
    y = newy;
    width = newWidth;
    height = newHeight;
    sprite = newSprite;
    frame = new int(1);
    animating = true;
    //ctor
}

AnimationObject::~AnimationObject()
{
    //dtor
}

bool AnimationObject::step()
{
    if (*frame == 0)
    {
        return false;
        //Blow up and die. AKA disappear.
    }
    if (animating == true)
    {
        *frame += 1;
    }
    return true;
}

type AnimationObject::getType()
{
    return ANIMATION;
}
