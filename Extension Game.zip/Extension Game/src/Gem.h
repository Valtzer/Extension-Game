#ifndef GEM_H
#define GEM_H

#include "Obstacle.h"
#include "Sprite.h"

class Gem: public Obstacle
{
    public:
        Gem(bool solid, int newx, int newy, int newWidth, int newHeight, Sprite* newSprite);
        virtual ~Gem();

        bool step();
        type getType();

        void collect();
    protected:
    private:
};

#endif // GEM_H
