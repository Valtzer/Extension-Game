#include "Hud.h"

#include "SpriteManager.h"
#include "Sprite.h"

Hud::Hud(SpriteManager* spriteControl)
{
    smallCoin = spriteControl->smallCoin;
    //ctor
    coinFrame = new int(0);
}

Hud::~Hud()
{
    //dtor
}

void Hud::draw(SDL_Surface* screen, int viewX, int viewY)
{
    //Fancy one here.
    SDL_Rect currentTile;
    currentTile.x = screen->w-8-2;
    currentTile.y = 2;
    //SDL_BlitSurface(smallCoin->getSheet(), smallCoin->getFrame(coinFrame), screen, &currentTile);
}

void Hud::step()
{
    *coinFrame += 1;
}
