#ifndef COIN_H
#define COIN_H

#include "Obstacle.h"
#include "Sprite.h"

class Coin: public Obstacle
{
    public:
        Coin(bool solid, int newx, int newy, int newWidth, int newHeight, Sprite* newSprite);
        virtual ~Coin();

        bool step();
        type getType();
    protected:
    private:
};

#endif // COIN_H
