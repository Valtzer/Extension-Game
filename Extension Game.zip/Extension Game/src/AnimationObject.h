#ifndef ANIMATIONOBJECT_H
#define ANIMATIONOBJECT_H

#include "Obstacle.h"
#include "Sprite.h"
#include "Room.h"

class AnimationObject: public Obstacle
{
    public:
        AnimationObject(bool solid, int newx, int newy, int newWidth, int newHeight, Sprite* newSprite);
        virtual ~AnimationObject();

        bool step();
        type getType();
    protected:
    private:
        Room* myRoom;
};

#endif // ANIMATIONOBJECT_H
