#ifndef SPRITE_H
#define SPRITE_H

#ifdef __cplusplus
    #include <cstdlib>
#else
    #include <stdlib.h>
#endif
#ifdef __APPLE__
#include <SDL/SDL.h>
#else
#include <SDL.h>
#endif

#include "Animation.h"
#include "Sprite.h"

class Sprite
{
    public:
        Sprite(SDL_Surface* newSheet, int newWidth, int newHeight, int newLength, int newY, int newX, int normalDelay);
        virtual ~Sprite();



        Animation frames;

        SDL_Surface* getSheet();
        SDL_Rect* getFrame(int* frame);
        void changeFrameTime(int time, int frame);
    protected:
    private:

        int width;
        int height;
        int length;
        int y;
        int x;
        SDL_Surface* sheet;

};

#endif // SPRITE_H
