#ifndef SPRINGPAD_H
#define SPRINGPAD_H

#include "Obstacle.h"
#include "Sprite.h"

class Springpad: public Obstacle
{
    public:
        Springpad(bool solid, int newx, int newy, int newWidth, int newHeight, Sprite* newSprite);
        virtual ~Springpad();

        bool step();
        type getType();
    protected:
    private:
};

#endif // SPRINGPAD_H
