#ifndef ANIMATION_H
#define ANIMATION_H

#ifdef __cplusplus
    #include <cstdlib>
#else
    #include <stdlib.h>
#endif
#ifdef __APPLE__
#include <SDL/SDL.h>
#else
#include <SDL.h>
#endif

#include <vector>

using namespace std;

class Animation
{
    public:
        Animation();
        virtual ~Animation();



        void addFrame(int x, int y, int width, int height, int frameEndtime);
        SDL_Rect* getFrame(int* frame);
        void changeFrameTime(int time, int frame);
    protected:
    private:
        vector<SDL_Rect*> images;
        vector<int> frameTimes;
};

#endif // ANIMATION_H
