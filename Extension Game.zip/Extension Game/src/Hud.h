#ifndef HUD_H
#define HUD_H

#include "SpriteManager.h"
#include "Sprite.h"

class Hud
{
    public:
        Hud(SpriteManager* spriteControl);
        virtual ~Hud();

        void draw(SDL_Surface* screen, int viewX, int viewY);
        void step();
    protected:
    private:
        int* coinFrame;
        Sprite* smallCoin;
};

#endif // HUD_H
