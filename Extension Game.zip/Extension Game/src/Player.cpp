#ifdef __cplusplus
    #include <cstdlib>
#else
    #include <stdlib.h>
#endif
#ifdef __APPLE__
#include <SDL/SDL.h>
#else
#include <SDL.h>
#endif

#include "globals.h"
#include "Player.h"
#include "Obstacle.h"

Player::Player(SDL_Surface* newScreen, int startX, int startY, SpriteManager* spriteControl)
{
    screen = newScreen;

    x = startX;
    y = startY;

    facing = RIGHT;

    xOrigin = PLAYER_WIDTH/2;
    yOrigin = PLAYER_HEIGHT/2;

    standRight = spriteControl->playerStandRight;
    standLeft = spriteControl->playerStandLeft;
    runRight = spriteControl->playerRunRight;
    runLeft = spriteControl->playerRunLeft;
    jumpRight = spriteControl->playerJumpRight;
    jumpLeft = spriteControl->playerJumpLeft;
    fallRight = spriteControl->playerFallRight;
    fallLeft = spriteControl->playerFallLeft;
    fallanimRight = spriteControl->playerFallanimRight;
    fallanimLeft = spriteControl->playerFallanimLeft;
    duckRight = spriteControl->playerDuckRight;
    duckLeft = spriteControl->playerDuckLeft;


    keystates = SDL_GetKeyState(NULL);

    gravity = 0.25;
    jumpSpeed = 5;
    vspeed = 0;

    frame = new int(0);

    currentSprite = standRight;
}

Player::~Player()
{
    //dtor
}

void Player::draw()
{

    int gridSpacex;
    int gridSpacey;
    gridSpacex = x/16;
    gridSpacey = y/16;
    gridSpacex *= 16;
    gridSpacey *= 16;
    int framePrevious;

    framePrevious = *frame;

    SDL_Rect currentSpace;
    currentSpace.x = (x-xOrigin)-currentLevel->getXView();
    currentSpace.y = (y-yOrigin)-currentLevel->getYView();
    SDL_BlitSurface(currentSprite->getSheet(), currentSprite->getFrame(frame), screen, &currentSpace);
    if (*frame == 0)
    {
        animationEnded = true;
        *frame = framePrevious;
        //Animation has ended. Might be useful later.
    }


}

void Player::setLevel(Room* newLevel)
{
    currentLevel = newLevel;
}

void Player::step()
{
    int moveCheck = 2;
    int i = 0;
    Obstacle* myItem;

    if (animationEnded == true)
    {
        if (currentSprite == fallanimRight)
        {
            currentSprite = fallRight;
        }
        if (currentSprite == fallanimLeft)
        {
            currentSprite = fallLeft;
        }
        *frame = 0;
        animationEnded = false;
    }

    //Check and move.
    if(keystates[SDLK_RIGHT])
    {
        facing = RIGHT;
        if (currentLevel->placeFree(x,y+1,MASK_WIDTH,MASK_HEIGHT,x,y,xOrigin,yOrigin) == false)
        {
            currentSprite = runRight;
        }
        //Make sure the two panels on your right are free.
        if (currentLevel->placeFree(x+moveCheck,y,MASK_WIDTH,MASK_HEIGHT,x,y,xOrigin,yOrigin))
        {
            x += moveCheck;
        }
        else
        if (currentLevel->placeFree(x+moveCheck,y-8,MASK_WIDTH,MASK_HEIGHT,x,y,xOrigin,yOrigin) && currentLevel->placeFree(x,y+1,MASK_WIDTH,MASK_HEIGHT,x,y,xOrigin,yOrigin) == false)
        {
            x += moveCheck;
            y -= 8;
        }
    }
    else
    if(keystates[SDLK_LEFT])
    {
        facing = LEFT;
        if (currentLevel->placeFree(x,y+1,MASK_WIDTH,MASK_HEIGHT,x,y,xOrigin,yOrigin) == false)
        {
            currentSprite = runLeft;
        }
        if (currentLevel->placeFree(x-moveCheck,y,MASK_WIDTH,MASK_HEIGHT,x,y,xOrigin,yOrigin))
        {
            x -= moveCheck;
        }
        else
        if (currentLevel->placeFree(x-moveCheck,y-8,MASK_WIDTH,MASK_HEIGHT,x,y,xOrigin,yOrigin) && currentLevel->placeFree(x,y+1,MASK_WIDTH,MASK_HEIGHT,x,y,xOrigin,yOrigin) == false)
        {
            x -= moveCheck;
            y -= 8;
        }
    }
    else
    {
        //Revert to standing sprite if you're not moving.
        if (currentSprite == runLeft)
        {
            currentSprite = standLeft;
        }
        if (currentSprite == runRight)
        {
            currentSprite = standRight;
        }
        //Some crouching business too...
        if(keystates[SDLK_DOWN])
        {
            if (currentLevel->placeFree(x,y+1,MASK_WIDTH,MASK_HEIGHT,x,y,xOrigin,yOrigin) == false && (vspeed > -0.05 && vspeed < 0.05))
            {
                if (facing == RIGHT)
                {
                    currentSprite = duckRight;
                }
                else
                if (facing == LEFT)
                {
                    currentSprite = duckLeft;
                }
            }
        }
        else
        {
            if (currentSprite == duckRight)
            {
                currentSprite = standRight;
            }
            else
            if (currentSprite == duckLeft)
            {
                currentSprite = standLeft;
            }
        }
    }


    if(keystates[SDLK_UP])
    {
        if (currentLevel->placeFree(x,y+1,MASK_WIDTH,MASK_HEIGHT,x,y,xOrigin,yOrigin) == false && (vspeed > -0.05 && vspeed < 0.05))
        {
            vspeed = -jumpSpeed;
        }
    }

    if (currentLevel->placeFree(x,y+1,MASK_WIDTH,MASK_HEIGHT,x,y,xOrigin,yOrigin))//Wheeee we're in the air.
    {
        vspeed += gravity;//Uh oh, gravity.
        if (vspeed < 0)
        {
            if (facing == RIGHT)
            {
                currentSprite = jumpRight;
            }
            else
            {
                currentSprite = jumpLeft;
            }
        }
        else//Going doooown...
        {
            if (facing == RIGHT)
            {
                if(currentSprite != fallRight && currentSprite != fallanimRight)
                {
                    if (currentSprite != fallanimLeft)
                    {
                        *frame = 0;
                    }
                    if (currentSprite == fallLeft)
                    {
                        currentSprite = fallRight;
                    }
                    else
                    {
                        currentSprite = fallanimRight;
                    }
                }
            }
            else
            {
                if(currentSprite != fallLeft && currentSprite != fallanimLeft)
                {
                    if (currentSprite != fallanimRight)
                    {
                        *frame = 0;
                    }
                    if (currentSprite == fallRight)
                    {
                        currentSprite = fallLeft;
                    }
                    else
                    {
                        currentSprite = fallanimLeft;
                    }
                }
            }
        }
    }

    if (currentLevel->placeFree(x,y+vspeed,MASK_WIDTH,MASK_HEIGHT,x,y,xOrigin,yOrigin) && (vspeed < -0.05 || vspeed > 0.05))
    {
        y += vspeed;
    }
    else
    {
        if (vspeed > 0.05)//Floor.
        {
            for (i = 0; i < vspeed; i += 1)
            {
                if (currentLevel->placeFree(x,y+1,MASK_WIDTH,MASK_HEIGHT,x,y,xOrigin,yOrigin))
                {
                    y += 1;
                }
            }
            //Ok, at this point we've concluded we've landed on something. From this point on it starts trying to land on the ground.
            //Check if there's an object below us or an actual floor.
            if (currentLevel->isFloor(x,y+vspeed,MASK_WIDTH,MASK_HEIGHT,x,y,xOrigin,yOrigin) == false)
            {
                //Do something. Dunno what yet. Let's just bounce for now. Change this later when springpads aren't the only terrain feature.
                myItem = currentLevel->objectAtPlace(x,y+vspeed,MASK_WIDTH,MASK_HEIGHT,x,y,xOrigin,yOrigin);
                if (myItem != 0)//Better make sure...
                {
                    if (myItem->getType() == SPRINGPAD)
                    {
                        myItem->startAnimating();
                        vspeed = -(int)vspeed;
                        if (facing == RIGHT)
                        {
                            currentSprite = jumpRight;
                        }
                        else
                        {
                            currentSprite = jumpLeft;
                        }
                    }
                }
            }
            else
            {
                vspeed = 0;
                if (facing == RIGHT)
                {
                    currentSprite = standRight;
                }
                else
                {
                    currentSprite = standLeft;
                }
            }
        }
        else
        if (vspeed < -0.05)//Ow ceiling.
        {
            for (i = 0; i < -vspeed; i += 1)
            {
                if (currentLevel->placeFree(x,y-1,MASK_WIDTH,MASK_HEIGHT,x,y,xOrigin,yOrigin))
                {
                    y -= 1;
                }
            }
            vspeed = 0;
        }

    }

    currentLevel->setView(x,y);


    //Alright, time to check for any coins or gems now.
    myItem = currentLevel->objectAtPlace(x,y,MASK_WIDTH,MASK_HEIGHT,x,y,xOrigin,yOrigin);
    if (myItem != 0)//Better make sure...
    {
        if (myItem->getType() == GEM)
        {

            //Destroy it?
            currentLevel->collectObject(myItem);
        }
    }
    *frame += 1;


}
