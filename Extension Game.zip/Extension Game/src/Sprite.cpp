#ifdef __cplusplus
    #include <cstdlib>
#else
    #include <stdlib.h>
#endif
#ifdef __APPLE__
#include <SDL/SDL.h>
#else
#include <SDL.h>
#endif

#include "Sprite.h"

Sprite::Sprite(SDL_Surface* newSheet, int newWidth, int newHeight, int newLength, int newY, int newX, int normalDelay = 5)
{
    sheet = newSheet;
    width = newWidth;
    height = newHeight;
    length = newLength;
    y = newY;
    x = newX;

    //frames = new Animation();
    int frameLength = normalDelay;
    int totalLength = 0;

    int i = 0;
    for(i = 0; i < length; i += 1)
    {
        totalLength += frameLength;
        frames.addFrame(x+(i*(width+1)),y,width,height,totalLength);

    }

    //ctor
}

Sprite::~Sprite()
{
    //dtor
}

SDL_Surface* Sprite::getSheet()
{
    return sheet;
}

SDL_Rect* Sprite::getFrame(int* frame)
{
    return frames.getFrame(frame);
}

void Sprite::changeFrameTime(int time, int frame)
{
    frames.changeFrameTime(time,frame);
}
