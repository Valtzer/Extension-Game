#ifdef __cplusplus
    #include <cstdlib>
#else
    #include <stdlib.h>
#endif
#ifdef __APPLE__
#include <SDL/SDL.h>
#else
#include <SDL.h>
#endif

#include <SDL_image.h>

#include <windows.h>

#include "src/SpriteManager.h"

//Define and create my SpriteManager singleton. Also means I can make classes call their own load image functions and create loading screens.

#include "src/globals.h"
#include "src/Room.h"
#include "src/Player.h"



const int TICKS_PER_SECOND = 60;
const int SKIP_TICKS = 1000 / TICKS_PER_SECOND;
const int MAX_FRAMESKIP = 5;



int main (int argc, char** argv)
{
    SpriteManager* spriteControl;
    spriteControl = new SpriteManager();

    Room* levelOne;
    Player* objPlayer;

    int nextGameTick = GetTickCount();
    int loops;


    // initialize SDL video
    if (SDL_Init(SDL_INIT_VIDEO) < 0)
    {
        printf( "Unable to init SDL: %s\n", SDL_GetError() );
        return 1;
    }

    // make sure SDL cleans up before exit
    atexit(SDL_Quit);

    // create a new window
    SDL_Surface* screen = SDL_SetVideoMode(320,240,16,SDL_HWSURFACE|SDL_DOUBLEBUF);
    if (!screen)
    {
        printf("Unable to set window dimensions: %s\n", SDL_GetError());
        return 1;
    }

    //Load tileset
    SDL_Surface* grassTiles = IMG_Load("tiles/grasstiles.png");
    if (!grassTiles)
    {
        printf("Unable to find tiles/grasstiles.bmp: %s\n", SDL_GetError());
        return 1;
    }
    //Load background
    SDL_Surface* skyBack = IMG_Load("backgrounds/sky.png");
    if (!skyBack)
    {
        printf("Unable to find backgrounds/sky.png: %s\n", SDL_GetError());
        return 1;
    }
    SDL_Surface* waterBack = IMG_Load("backgrounds/water.png");
    if (!skyBack)
    {
        printf("Unable to find backgrounds/water.png: %s\n", SDL_GetError());
        return 1;
    }
    SDL_Surface* mountainBack = IMG_Load("backgrounds/mountain1.png");
    if (!mountainBack)
    {
        printf("Unable to find backgrounds/mountain1.png: %s\n", SDL_GetError());
        return 1;
    }
    SDL_Surface* cloudBack = IMG_Load("backgrounds/clouds.png");
    if (!cloudBack)
    {
        printf("Unable to find backgrounds/clouds.png: %s\n", SDL_GetError());
        return 1;
    }

    levelOne = new Room(grassTiles,screen,skyBack,waterBack,mountainBack,cloudBack,spriteControl);
    objPlayer = new Player(/*playerSheet,playerSheetleft,*/screen,40,32,spriteControl);

    objPlayer->setLevel(levelOne);


    // program main loop
    bool done = false;
    while (!done)
    {
        loops = 0;

        while(GetTickCount() > nextGameTick && loops < MAX_FRAMESKIP)
        {
            levelOne->step();
            objPlayer->step();
            SDL_Event event;
            while (SDL_PollEvent(&event))
            {
                switch (event.type)
                {
                    // exit if the window is closed
                    case SDL_QUIT:
                        done = true;
                    break;

                    case SDL_KEYDOWN:
                    {
                        // exit if ESCAPE is pressed
                        if (event.key.keysym.sym == SDLK_ESCAPE)
                            done = true;
                        break;
                    }
                }
            } // end of message processing
            nextGameTick += SKIP_TICKS;
            loops++;
        }

        // DRAWING STARTS HERE

        // clear screen
        SDL_FillRect(screen, 0, SDL_MapRGB(screen->format, 0, 0, 0));

        // draw bitmap
        //SDL_BlitSurface(grassTiles, 0, screen, &dstrect);

        levelOne->draw();
        objPlayer->draw();
        //SDL_BlitSurface(grassTiles, &tileEqualsCell, screen, &dstrect);

        // DRAWING ENDS HERE

        // finally, update the screen :)
        SDL_Flip(screen);
    } // end main loop

    // free loaded bitmap
    SDL_FreeSurface(grassTiles);

    delete spriteControl;

    // all is well ;)
    printf("Exited cleanly\n");
    return 0;
}
